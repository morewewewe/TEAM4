/*
blink.h -Simple example in creating your own Arduino Library
Copyright(c)2017 op of TMM.All right reserved.

A pin is blinked automatically by one second intervals or by a specified interval

Methods:
Blink(pin)-Constructor.Specify pin to blink

blink(value,length)-Enable blinking and specify interval of blinking.
*/

#ifndef Blink_h
#define Blink_h
#include <Arduino.h>
#define ON true
#define OFF false
class Blink
{
public:
Blink(int pin);//Constructor.attach pin to blink

void blink(bool value,int blinkLength);//enable blinking with blink duration

private:
uint8_t pinNumber;
}；
#endif